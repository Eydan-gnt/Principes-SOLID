/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fr.paulr.empruntbibliotheque;

/**
 *
 * @author Utilisateur
 */
public class DVD extends Item implements ArticleRetournable, Penalite{

    public DVD(String name) {
        super(name);
    }

    @Override
    public void rendreArticle() {
        System.out.println("DVD rendu : " + getTitre());
    }
    
    @Override
    public void processItem() {
        rendreArticle();
        imprimeEtiquette();
        ConnecteurMySql.connect("localhost", 3306, "root", "root");
    }

    @Override
    public void calculerPenaliteDeRetard(int jours) {
        System.out.println("Forfait : 50 euros quel que soit le nombre de jours de retard.");
    }

    @Override
    public void imprimeEtiquette() {
        System.out.println("Etiquette DVD : " + getTitre());
    }

}