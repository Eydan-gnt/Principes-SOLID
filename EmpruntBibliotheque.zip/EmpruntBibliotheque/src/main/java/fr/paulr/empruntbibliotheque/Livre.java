/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fr.paulr.empruntbibliotheque;

/**
 *
 * @author Utilisateur
 */
public class Livre extends Item implements ArticleEmpruntable, ArticleRetournable, Penalite {
    private boolean emprunte;

    public Livre(String name) {
        super(name);
    }

    @Override
    public void emprunter() {
        emprunte = true;
        System.out.println("Livre emprunté : " + getTitre());
    }

    @Override
    public void rendreArticle() {
        emprunte = false;
        System.out.println("Livre rendu : " + getTitre());
    }
    
    @Override
    public void processItem () {
        emprunter();
        imprimeEtiquette();
        ConnecteurMySql.connect("localhost", 3306, "root", "root");
        EmailSmtp.send("user@example.com","Message de votre bibliothèque","Livre emprunté");
    }

    // LSP violé : comportement incohérent
    @Override
    public void calculerPenaliteDeRetard(int jours) {
        if (jours < 0) {
            throw new IllegalArgumentException("Le nombre de jours ne peut pas être négatif !");
        } else {
            System.out.println("Pénalités de retard : " + (jours * 10) + " euros");
        }
    }

    @Override
    public void imprimeEtiquette() {
        System.out.println("Etiquette : " + getTitre());
    }

}
