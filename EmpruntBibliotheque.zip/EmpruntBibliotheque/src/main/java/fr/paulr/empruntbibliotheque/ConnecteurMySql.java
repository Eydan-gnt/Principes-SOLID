/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fr.paulr.empruntbibliotheque;

/**
 *
 * @author Utilisateur
 */
public class ConnecteurMySql {
      public static void connect(String host, int port, String user, String pass) {
        System.out.println("Connexion à MySQL à " + host + " : " + port);
    }
}
