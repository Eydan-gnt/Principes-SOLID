/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fr.paulr.empruntbibliotheque;

/**
 *
 * @author e.gannot
 */
public abstract class Item implements Etiquette {
    private String titre;
    
    protected Item(String name) {
        this.titre=name;
    }
    
    public String getTitre() {
        return this.titre;
    }
    
    public void processItem () {
        
    }
    
}
